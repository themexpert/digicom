<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', 'rev74D4D28');
define('AKEEBA_DATE', '2014-08-20');